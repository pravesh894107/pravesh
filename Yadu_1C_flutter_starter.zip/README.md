# Yadu 1C — Flutter Starter

यह शुरुआती Android prototype है जिसमें Login/Signup UI, Home Feed, Reels placeholder, Chat placeholder, Invite & Earn और Wallet demo screens शामिल हैं।

## चलाने के लिए
1. Flutter SDK और Android Studio इंस्टॉल करें।
2. इस folder में terminal खोलें।
3. `flutter pub get`
4. `flutter run`

यह prototype अभी production backend, real chat, authentication, payments या real earning system से जुड़ा नहीं है।
